import UIKit

class time{
    var days = 0;
    var hours = 0;
    var minutes = 0;
    var seconds = 0;
    
    func increment(){
        
    }
}
